"""LimCore's Decky backend: runs as the deck user, drives LimCore through its control socket.

LimCore does the work (servers, settings, the root service that holds the TUN). In Game Mode
there is no LimCore window, so the plugin starts `limcore --headless` and keeps its stdin: when
the plugin's process ends, LimCore quits and the VPN goes down with it, as when the app is
closed. A LimCore that already runs (the window in Desktop Mode) is used instead.
"""

import asyncio
import json
import os
from pathlib import Path
import re
import ssl
import time
import urllib.request

import decky

CONTROL_TIMEOUT = 5
# A headless LimCore nobody asks about and that isn't connected quits after this long.
IDLE_SECONDS = 120
RELEASE_BASE = "https://raw.githubusercontent.com/l-limon-l/LimCore-Linux/main/"


def plugin_version():
    return json.loads(Path(__file__).with_name("package.json").read_text())["version"]


def plugin_release(manifest, current):
    """Only the published LimCore plugin ZIP may be sent to Decky's installer."""
    asset = manifest.get("decky")
    if not isinstance(asset, dict):
        return {"state": "unavailable", "current": current}
    version = asset.get("version", "")
    checksum = asset.get("sha256", "")
    if (not re.fullmatch(r"\d+\.\d+\.\d+", version)
            or asset.get("file") != "decky/LimCore-decky.zip"
            or not re.fullmatch(r"[a-fA-F0-9]{64}", checksum)):
        raise ValueError("Invalid Decky update manifest")
    installed = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:[-+][\w.+-]+)?", current)
    if not installed:
        raise ValueError("Invalid installed plugin version")
    checksum = checksum.lower()
    newer = tuple(map(int, version.split("."))) > tuple(map(int, installed.groups()))
    return {"state": "available" if newer else "upToDate", "current": current,
            "version": version, "sha256": checksum,
            "url": RELEASE_BASE + asset["file"] + "?sha256=" + checksum}


# Decky's embedded Python can have OpenSSL defaults pointing at its build host.
# Add the host OS trust store while keeping Python/env trust and TLS verification.
SYSTEM_CA_FILES = (
    "/etc/ssl/certs/ca-certificates.crt",  # SteamOS / Arch / Debian
    "/etc/ssl/cert.pem",
    "/etc/pki/tls/certs/ca-bundle.crt",
)


def plugin_tls_context():
    context = ssl.create_default_context()
    for path in SYSTEM_CA_FILES:
        if os.path.isfile(path):
            context.load_verify_locations(cafile=path)
    return context


def check_plugin_release():
    request = urllib.request.Request(RELEASE_BASE + "update.json?t=" + str(int(time.time())),
                                     headers={"User-Agent": "LimCore-Decky/" + plugin_version()})
    with urllib.request.urlopen(request, timeout=25, context=plugin_tls_context()) as response:
        body = response.read(1024 * 1024 + 1)
    if len(body) > 1024 * 1024:
        raise ValueError("Update manifest is too large")
    return plugin_release(json.loads(body), plugin_version())


# What "Send logs" adds of the plugin's own: its log and the headless LimCore's console.
PLUGIN_LOG_LIMIT = 96 * 1024


def plugin_logs(directory, limit=PLUGIN_LOG_LIMIT):
    """The tails of the plugin's log files, newest first, within [limit] bytes in all."""
    try:
        files = sorted((entry for entry in os.scandir(directory) if entry.is_file() and entry.name.endswith(".log")),
                       key=lambda entry: entry.stat().st_mtime, reverse=True)
    except OSError:
        return ""
    parts = []
    left = limit
    for entry in files[:4]:
        if left <= 0:
            break
        try:
            with open(entry.path, "rb") as log:
                size = log.seek(0, os.SEEK_END)
                log.seek(max(0, size - left))
                text = log.read().decode("utf-8", "replace")
        except OSError:
            continue
        left -= len(text)
        parts.append(f"== decky {entry.name}\n{text}")
    return "\n".join(parts)


def control_path():
    runtime = f"/run/user/{os.getuid()}"
    if os.path.isdir(runtime):
        return os.path.join(runtime, "limcore-control.sock")
    return f"/tmp/limcore-control-{os.getuid()}.sock"


def launcher():
    """The installed LimCore: the AppImage its installer put in place, or a .deb/.rpm's."""
    home = getattr(decky, "DECKY_USER_HOME", None) or os.path.expanduser("~")
    data = os.environ.get("XDG_DATA_HOME") or os.path.join(home, ".local", "share")
    for path in (os.path.join(data, "LimCore", "LimCore.AppImage"), "/usr/bin/limcore"):
        if os.access(path, os.X_OK):
            return path
    return None


async def ask(request, timeout=CONTROL_TIMEOUT):
    reader, writer = await asyncio.wait_for(asyncio.open_unix_connection(control_path()), timeout)
    try:
        writer.write((json.dumps(request) + "\n").encode())
        await writer.drain()
        line = await asyncio.wait_for(reader.readline(), timeout)
    finally:
        writer.close()
    if not line:
        raise ConnectionError("LimCore closed the connection")
    return json.loads(line)


class Plugin:
    async def _main(self):
        self.process = None
        self.last_request = time.monotonic()
        self.starting = asyncio.Lock()
        self.update_task = None
        self.plugin_update = {"state": "idle", "current": plugin_version()}
        self.idle_task = asyncio.get_event_loop().create_task(self._watch_idle())
        decky.logger.info("LimCore plugin loaded, control socket %s", control_path())

    async def _unload(self):
        self.idle_task.cancel()
        if self.update_task:
            self.update_task.cancel()
        await self._stop_headless()

    async def _uninstall(self):
        if self.update_task:
            self.update_task.cancel()
        await self._stop_headless()

    # Called from the Quick Access panel.

    async def get_state(self):
        """LimCore's state; starts a headless LimCore if none runs."""
        if not launcher() and not await self._answers():
            return {"available": False}
        try:
            state = await self._request({"method": "state"})
        except Exception as error:  # noqa: BLE001 — shown in the panel
            decky.logger.error("state: %s", error)
            return {"available": True, "running": False, "error": str(error)}
        state.update(available=True, running=True)
        return state

    async def get_servers(self):
        return await self._request({"method": "servers"})

    async def connect(self, server_id=""):
        return await self._request({"method": "connect", "id": server_id or ""})

    async def disconnect(self):
        return await self._request({"method": "disconnect"})

    async def select(self, server_id):
        return await self._request({"method": "select", "id": server_id})

    async def ping(self):
        return await self._request({"method": "ping"})

    async def refresh(self):
        return await self._request({"method": "refresh"})

    async def stop_interceptors(self):
        return await self._request({"method": "stopInterceptors"})

    # Feedback: LimCore's telemetry (same install id, consent settings and scrubbing as the app).

    async def set_telemetry(self, usage=None, errors=""):
        request = {"method": "setTelemetry", "errors": errors or ""}
        if isinstance(usage, bool):
            request["usage"] = usage
        return await self._request(request)

    async def send_logs(self, note=""):
        extra = f"== decky plugin {plugin_version()}\n" + plugin_logs(decky.DECKY_PLUGIN_LOG_DIR)
        return await self._request({"method": "sendLogs", "note": str(note)[:2000], "extra": extra})

    async def crash_report(self, action):
        return await self._request({"method": "crashReport", "action": action})

    async def report_error(self, message, stack=""):
        """An error in the plugin's panel; LimCore sends it only if error reports are automatic."""
        decky.logger.error("panel: %s", message)
        try:
            return await self._request({"method": "pluginError", "message": f"[plugin {plugin_version()}] {message}"[:2000],
                                        "stack": str(stack)[:30000],
                                        "log": plugin_logs(decky.DECKY_PLUGIN_LOG_DIR, 32 * 1024)})
        except Exception as error:  # noqa: BLE001 — reporting must never break the panel
            decky.logger.error("error report: %s", error)
            return {}

    async def get_processes(self):
        return await self._request({"method": "processes"})

    async def set_per_app(self, mode, apps):
        return await self._request({"method": "setPerApp", "mode": mode, "apps": apps})

    async def check_update(self):
        return await self._request({"method": "checkUpdate"})

    async def install_update(self):
        state = await self._request({"method": "installUpdate"})
        if state.get("headless") and not self.update_task:
            self.update_task = asyncio.create_task(self._watch_update())
        return state

    async def update_service(self):
        return await self._request({"method": "updateService"})

    async def get_plugin_update(self):
        return self.plugin_update

    async def check_plugin_update(self):
        if self.plugin_update["state"] == "checking":
            return self.plugin_update
        self.plugin_update = {"state": "checking", "current": plugin_version()}
        try:
            self.plugin_update = await asyncio.to_thread(check_plugin_release)
        except Exception as error:  # noqa: BLE001 — shown in the panel
            self.plugin_update = {"state": "failed", "current": plugin_version(), "error": str(error)}
        return self.plugin_update

    # LimCore.

    async def _request(self, request):
        self.last_request = time.monotonic()
        try:
            reply = await ask(request)
        except (OSError, asyncio.TimeoutError, ConnectionError):
            await self._start_headless()
            reply = await ask(request)
        if "error" in reply and "state" not in reply:
            raise RuntimeError(reply["error"])
        return reply

    async def _watch_update(self):
        """Own the new headless child's stdin too; never spawn a Game Mode window."""
        try:
            deadline = time.monotonic() + 15 * 60
            while time.monotonic() < deadline:
                await asyncio.sleep(1)
                self.last_request = time.monotonic()
                try:
                    state = await ask({"method": "state"})
                except (OSError, asyncio.TimeoutError, ConnectionError):
                    if self.process and self.process.returncode is None:
                        continue
                    await self._start_headless()
                    return
                if state.get("updater", {}).get("state") == "failed":
                    return
        except Exception as error:  # noqa: BLE001
            decky.logger.error("restarting after update: %s", error)
        finally:
            self.update_task = None

    async def _answers(self):
        try:
            await ask({"method": "state"}, timeout=1)
            return True
        except Exception:  # noqa: BLE001
            return False

    async def _start_headless(self):
        async with self.starting:
            if await self._answers():
                return
            path = launcher()
            if not path:
                raise RuntimeError("LimCore isn't installed")
            await self._stop_headless()
            home = getattr(decky, "DECKY_USER_HOME", None) or os.path.expanduser("~")
            uid = os.getuid()
            env = {k: v for k, v in os.environ.items() if not k.startswith(("QT_", "LD_", "PYTHON"))}
            env.update(HOME=home, XDG_CONFIG_HOME=os.path.join(home, ".config"),
                       XDG_DATA_HOME=os.path.join(home, ".local", "share"))
            env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{uid}")
            env.setdefault("DBUS_SESSION_BUS_ADDRESS", f"unix:path=/run/user/{uid}/bus")
            env.setdefault("USER", getattr(decky, "DECKY_USER", "") or env.get("USER", "deck"))
            # FUSE may be missing for the AppImage: then it runs from an extracted copy.
            for extract in (False, True):
                if extract:
                    env["APPIMAGE_EXTRACT_AND_RUN"] = "1"
                log = open(os.path.join(decky.DECKY_PLUGIN_LOG_DIR, "limcore-headless.log"), "ab")
                decky.logger.info("starting %s --headless%s", path, " (extracted)" if extract else "")
                self.process = await asyncio.create_subprocess_exec(
                    path, "--headless", stdin=asyncio.subprocess.PIPE, stdout=log, stderr=log,
                    env=env, cwd=home)
                log.close()
                for _ in range(200 if extract else 100):
                    if await self._answers():
                        return
                    if self.process.returncode is not None:
                        break
                    await asyncio.sleep(0.2)
                decky.logger.error("LimCore --headless didn't answer (exit %s)", self.process.returncode)
                await self._stop_headless()
                if not path.endswith(".AppImage"):
                    break
            raise RuntimeError("LimCore didn't start")

    async def _stop_headless(self):
        process, self.process = getattr(self, "process", None), None
        if not process or process.returncode is not None:
            return
        # Closing its stdin is LimCore's signal to quit (and to take the tunnel down).
        try:
            process.stdin.close()
            await asyncio.wait_for(process.wait(), 8)
        except (asyncio.TimeoutError, OSError):
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), 3)
            except asyncio.TimeoutError:
                process.kill()

    async def _watch_idle(self):
        while True:
            await asyncio.sleep(30)
            if not self.process or self.process.returncode is not None:
                continue
            if time.monotonic() - self.last_request < IDLE_SECONDS:
                continue
            if self.update_task:
                continue
            try:
                state = await ask({"method": "state"})
            except Exception:  # noqa: BLE001
                continue
            updating = state.get("updater", {}).get("state") in ("checking", "downloading")
            if not updating and state.get("headless") and state.get("state") == "disconnected":
                decky.logger.info("LimCore idle and disconnected: stopping it")
                await self._stop_headless()
