"""LimCore's Decky backend: runs as the deck user, drives LimCore through its control socket.

LimCore does the work (servers, settings, the root service that holds the TUN). In Game Mode
there is no LimCore window, so the plugin starts `limcore --headless` and keeps its stdin: when
the plugin's process ends, LimCore quits and the VPN goes down with it, as when the app is
closed. A LimCore that already runs (the window in Desktop Mode) is used instead.
"""

import asyncio
import json
import os
import time

import decky

CONTROL_TIMEOUT = 5
# A headless LimCore nobody asks about and that isn't connected quits after this long.
IDLE_SECONDS = 120


def control_path():
    runtime = f"/run/user/{os.getuid()}"
    if os.path.isdir(runtime):
        return os.path.join(runtime, "limcore-control.sock")
    return f"/tmp/limcore-control-{os.getuid()}.sock"


def launcher():
    """The installed LimCore: the AppImage its installer put in place, or a .deb/.rpm's."""
    home = getattr(decky, "DECKY_USER_HOME", None) or os.path.expanduser("~")
    data = os.environ.get("XDG_DATA_HOME") or os.path.join(home, ".local", "share")
    for path in (os.path.join(data, "LimCore", "LimCore.AppImage"), "/usr/bin/limcore"):
        if os.access(path, os.X_OK):
            return path
    return None


async def ask(request, timeout=CONTROL_TIMEOUT):
    reader, writer = await asyncio.wait_for(asyncio.open_unix_connection(control_path()), timeout)
    try:
        writer.write((json.dumps(request) + "\n").encode())
        await writer.drain()
        line = await asyncio.wait_for(reader.readline(), timeout)
    finally:
        writer.close()
    if not line:
        raise ConnectionError("LimCore closed the connection")
    return json.loads(line)


class Plugin:
    async def _main(self):
        self.process = None
        self.last_request = time.monotonic()
        self.starting = asyncio.Lock()
        self.idle_task = asyncio.get_event_loop().create_task(self._watch_idle())
        decky.logger.info("LimCore plugin loaded, control socket %s", control_path())

    async def _unload(self):
        self.idle_task.cancel()
        await self._stop_headless()

    async def _uninstall(self):
        await self._stop_headless()

    # Called from the Quick Access panel.

    async def get_state(self):
        """LimCore's state; starts a headless LimCore if none runs."""
        if not launcher() and not await self._answers():
            return {"available": False}
        try:
            state = await self._request({"method": "state"})
        except Exception as error:  # noqa: BLE001 — shown in the panel
            decky.logger.error("state: %s", error)
            return {"available": True, "running": False, "error": str(error)}
        state.update(available=True, running=True)
        return state

    async def get_servers(self):
        return await self._request({"method": "servers"})

    async def connect(self, server_id=""):
        return await self._request({"method": "connect", "id": server_id or ""})

    async def disconnect(self):
        return await self._request({"method": "disconnect"})

    async def select(self, server_id):
        return await self._request({"method": "select", "id": server_id})

    async def ping(self):
        return await self._request({"method": "ping"})

    async def refresh(self):
        return await self._request({"method": "refresh"})

    async def stop_interceptors(self):
        return await self._request({"method": "stopInterceptors"})

    # LimCore.

    async def _request(self, request):
        self.last_request = time.monotonic()
        try:
            return await ask(request)
        except (OSError, asyncio.TimeoutError, ConnectionError):
            await self._start_headless()
            return await ask(request)

    async def _answers(self):
        try:
            await ask({"method": "state"}, timeout=1)
            return True
        except Exception:  # noqa: BLE001
            return False

    async def _start_headless(self):
        async with self.starting:
            if await self._answers():
                return
            path = launcher()
            if not path:
                raise RuntimeError("LimCore isn't installed")
            await self._stop_headless()
            home = getattr(decky, "DECKY_USER_HOME", None) or os.path.expanduser("~")
            uid = os.getuid()
            env = {k: v for k, v in os.environ.items() if not k.startswith(("QT_", "LD_", "PYTHON"))}
            env.update(HOME=home, XDG_CONFIG_HOME=os.path.join(home, ".config"),
                       XDG_DATA_HOME=os.path.join(home, ".local", "share"))
            env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{uid}")
            env.setdefault("DBUS_SESSION_BUS_ADDRESS", f"unix:path=/run/user/{uid}/bus")
            env.setdefault("USER", getattr(decky, "DECKY_USER", "") or env.get("USER", "deck"))
            # FUSE may be missing for the AppImage: then it runs from an extracted copy.
            for extract in (False, True):
                if extract:
                    env["APPIMAGE_EXTRACT_AND_RUN"] = "1"
                log = open(os.path.join(decky.DECKY_PLUGIN_LOG_DIR, "limcore-headless.log"), "ab")
                decky.logger.info("starting %s --headless%s", path, " (extracted)" if extract else "")
                self.process = await asyncio.create_subprocess_exec(
                    path, "--headless", stdin=asyncio.subprocess.PIPE, stdout=log, stderr=log,
                    env=env, cwd=home)
                log.close()
                for _ in range(200 if extract else 100):
                    if await self._answers():
                        return
                    if self.process.returncode is not None:
                        break
                    await asyncio.sleep(0.2)
                decky.logger.error("LimCore --headless didn't answer (exit %s)", self.process.returncode)
                await self._stop_headless()
                if not path.endswith(".AppImage"):
                    break
            raise RuntimeError("LimCore didn't start")

    async def _stop_headless(self):
        process, self.process = getattr(self, "process", None), None
        if not process or process.returncode is not None:
            return
        # Closing its stdin is LimCore's signal to quit (and to take the tunnel down).
        try:
            process.stdin.close()
            await asyncio.wait_for(process.wait(), 8)
        except (asyncio.TimeoutError, OSError):
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), 3)
            except asyncio.TimeoutError:
                process.kill()

    async def _watch_idle(self):
        while True:
            await asyncio.sleep(30)
            if not self.process or self.process.returncode is not None:
                continue
            if time.monotonic() - self.last_request < IDLE_SECONDS:
                continue
            try:
                state = await ask({"method": "state"})
            except Exception:  # noqa: BLE001
                continue
            if state.get("headless") and state.get("state") == "disconnected":
                decky.logger.info("LimCore idle and disconnected: stopping it")
                await self._stop_headless()
